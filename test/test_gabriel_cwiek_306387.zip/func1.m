function [y] = func1(x)
y = x.^2+ x+ 1;
end