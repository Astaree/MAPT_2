function [y] = func2(x)
y= x.^3+x.^2+x+1;
end